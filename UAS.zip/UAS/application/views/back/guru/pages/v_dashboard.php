<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Control</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= site_url('guru')?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      </ol>
    </section>
    <section class="content">
        <!-- Small boxes (Stat box) -->
        <h3>Dosen</h3>  
    </section>

</div>
<!-- /.content-wrapper -->